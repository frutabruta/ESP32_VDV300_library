#ifndef IBIS_h
#define IBIS_h
#include "Arduino.h"
class IBIS
{
  public:
  IBIS();
  void dopocetCelni(String puvodniPrikaz);
  void smazPanely();	
  
};

#endif