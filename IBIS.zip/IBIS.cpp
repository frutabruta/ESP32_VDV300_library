#include "Arduino.h"
#include "IBIS.h"

IBIS::IBIS()
{}




void IBIS::dopocetCelni (String puvodniPrikaz)
       {
        String prikaz = "";
    //byte velikostMezipameti=200;
    //char mezipamet[velikostMezipameti];
   //String mezipamet="";
    char zacatecniByte=0x7F;
    String ridiciZnak ="";
   
    byte jeZnak=5;
    
    char hexridiciznak[3];
    byte hex1=0;
    byte hex2=0;
    //String retezec="";
        puvodniPrikaz.replace("�","<0E><20>");
        puvodniPrikaz.replace("�","<0E><0F>");
        puvodniPrikaz.replace("�","<0E><07>");
        puvodniPrikaz.replace("�","<0E><00>");
        puvodniPrikaz.replace("�","<0E><03>");
        puvodniPrikaz.replace("�","<0E><05>");
        puvodniPrikaz.replace("�","<0E><02>");
        puvodniPrikaz.replace("�","<0E><10>");
        puvodniPrikaz.replace("�","<0E><08>");
        puvodniPrikaz.replace("�","<0E><09>");
        puvodniPrikaz.replace("�","<0E><21>");
        puvodniPrikaz.replace("�","<0E><0B>");
        puvodniPrikaz.replace("�","<0E><24>");
        puvodniPrikaz.replace("�","<0E><25>");
        puvodniPrikaz.replace("�","<0E><22>");
        puvodniPrikaz.replace("�","<0E><15>");
        puvodniPrikaz.replace("�","<0E><29>");
        puvodniPrikaz.replace("�","<0E><1E>");
        puvodniPrikaz.replace("�","<0E><28>");
        puvodniPrikaz.replace("�","<0E><1B>");
        puvodniPrikaz.replace("�","<0E><1F>");
        puvodniPrikaz.replace("�","<0E><06>");
        puvodniPrikaz.replace("�","<0E><23>");
        puvodniPrikaz.replace("�","<0E><16>");
        puvodniPrikaz.replace("�","<0E><26>");
        puvodniPrikaz.replace("�","<0E><18>");
        puvodniPrikaz.replace("�","<0E><1D>");
        puvodniPrikaz.replace("�","<0E><11>");
        puvodniPrikaz.replace("�","<0E><12>");
        
        
        
        prikaz=puvodniPrikaz+'\r';
       //mezipamet=prikaz;
        //prikaz.toCharArray(mezipamet, velikostMezipameti);
        /*
        zacatecnibyte=zacatecnibyte^0x7A;
        Serial3.write(0x7A);
         zacatecnibyte=zacatecnibyte^0x41;
        Serial3.write(0x41);
         zacatecnibyte=zacatecnibyte^0x20;
        Serial3.write(0x20);
        zacatecnibyte=zacatecnibyte^0x1B;
        Serial3.write(0x1B);
        zacatecnibyte=zacatecnibyte^0x57;
        Serial3.write(0x57);
        */
        
        
        
        for (int k=0; k<prikaz.length(); k++)
        {
          if (prikaz[k]=='<')
          {
            jeZnak=0;
          }
          if (prikaz[k]=='>')
          {
            jeZnak=4;
          }
          switch (jeZnak)
            {
              case 0:
              jeZnak++;
              break;
              
              case 1:
              hexridiciznak[0]=prikaz[k];
              jeZnak++;
              break;
              
              case 2:
              hexridiciznak[1]=prikaz[k];
              jeZnak++;
              //zacatecniByte=zacatecniByte^atoi(hexridiciznak);
              break;
              
              case 3:
              hexridiciznak[2]=prikaz[k];
              jeZnak++;
              
              break;
              
              
              case 4:
              
              zacatecniByte=zacatecniByte^int(strtol(hexridiciznak,NULL,16));
              Serial.write(int(strtol(hexridiciznak,NULL,16)));
              Serial3.write(int(strtol(hexridiciznak,NULL,16)));
              hexridiciznak[0]=0;
              hexridiciznak[1]=0;
              hexridiciznak[2]=0;
              jeZnak++;
              break;
              
              case 5:
              zacatecniByte=zacatecniByte^prikaz[k];
              Serial.print(prikaz[k]);
              Serial3.print(prikaz[k]);
              break;
              
            
          }
          
          //Serial.print("   ");
        }
        //Serial3.print(prikaz);
        Serial.print(zacatecniByte);
        Serial3.print(zacatecniByte);
        
        
       }
       
       
void IBIS::smazPanely ()
{
    String prikaz="";
  prikaz="zA ";
  dopocetCelni(prikaz);
  
  prikaz="zN ";
  dopocetCelni(prikaz);
  
  prikaz="zI2 ";
  dopocetCelni(prikaz);
  
  prikaz="l000";
  dopocetCelni(prikaz);
}       

